function abreSteam() {
    window.location.replace("http://store.steampowered.com");
}

function abreSteam(codJogo) {

    document.window.alert("FON");

}
